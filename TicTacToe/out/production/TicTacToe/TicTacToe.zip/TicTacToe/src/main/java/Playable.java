public interface Playable {
    public void play(Player player);
}
